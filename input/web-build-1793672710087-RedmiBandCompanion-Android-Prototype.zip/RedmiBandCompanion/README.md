# Redmi Band Companion — prototype 0.1

This is the first Android Studio project for an independent Redmi/Xiaomi Smart Band 5 companion app.

## Current functionality
- Requests the Android Bluetooth permissions.
- Scans nearby Bluetooth Low Energy advertisements for 12 seconds.
- Lists discovered BLE devices, their advertised names, addresses and signal strength.
- Does **not** yet connect, authenticate, read health data, or change band settings.

## Build
1. Install Android Studio (recent stable version) and Android SDK 35.
2. Open this folder as a project.
3. Let Gradle sync.
4. Connect your Android phone, enable Developer options + USB debugging, and press Run.
5. Grant Nearby devices permission when prompted.
6. Keep the band close and awake, then tap **Scan for bands**.

## Important pairing/key note
Do not factory-reset the band. Mi Band 5 uses server-based initial pairing and a device-specific authentication key. Since this band was previously paired, the next task is to recover the existing key from the original Zepp Life installation/account if possible, or from a previously paired phone backup. The app must never ask you to share the key in chat; it should be entered locally and stored securely.

## Next implementation milestones
1. Identify the band advertisement and GATT characteristics.
2. Add a local encrypted auth-key field using Android Keystore.
3. Implement the Mi Band 5 challenge-response authentication and verify battery read.
4. Add steps, heart-rate stream, history sync and vibration.
5. Add alarms, notifications and configuration where supported by firmware.

## Protocol reference
The project `Erencv/miband5-ble` documents the Mi Smart Band 5 BLE protocol and a working Python implementation. It is a protocol reference, not Android application code. Firmware differences may affect behavior.
