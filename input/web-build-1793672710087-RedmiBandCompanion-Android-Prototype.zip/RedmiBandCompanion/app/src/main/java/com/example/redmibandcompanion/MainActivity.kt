package com.example.redmibandcompanion

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var results: TextView
    private lateinit var scanButton: Button
    private var scanner: BluetoothLeScanner? = null
    private val handler = Handler(Looper.getMainLooper())
    private val found = linkedMapOf<String, String>()

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val address = try { device.address } catch (_: SecurityException) { "Address unavailable" }
            val name = result.scanRecord?.deviceName
                ?: try { device.name } catch (_: SecurityException) { null }
                ?: "Unnamed BLE device"
            val rssi = result.rssi
            found[address] = "$name\n  $address  •  RSSI $rssi dBm"
            runOnUiThread { renderResults() }
        }

        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = "Bluetooth scan failed (code $errorCode)" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFFF6F7F9.toInt())
        }
        val title = TextView(this).apply {
            text = "Redmi Band Companion"
            textSize = 25f
            setTextColor(0xFF17191C.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Independent Bluetooth companion • Early prototype"
            textSize = 14f
            setTextColor(0xFF626A73.toInt())
            setPadding(0, 8, 0, 24)
        }
        status = TextView(this).apply {
            text = "Ready. Turn on Bluetooth and keep the band close."
            textSize = 16f
            setTextColor(0xFF20252B.toInt())
            setPadding(0, 12, 0, 16)
        }
        scanButton = Button(this).apply {
            text = "Scan for bands"
            setOnClickListener { startScan() }
        }
        val section = TextView(this).apply {
            text = "Nearby Bluetooth devices"
            textSize = 18f
            setTextColor(0xFF17191C.toInt())
            setPadding(0, 26, 0, 12)
        }
        results = TextView(this).apply {
            text = "No scan results yet."
            textSize = 15f
            setTextColor(0xFF30363D.toInt())
        }
        val scroll = ScrollView(this).apply { addView(results) }
        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(status)
        outer.addView(scanButton)
        outer.addView(section)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }

    private fun requestBlePermissions() {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 100)
    }

    private fun hasPermissions(): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun startScan() {
        if (!hasPermissions()) {
            requestBlePermissions()
            status.text = "Bluetooth permissions are required."
            return
        }
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            status.text = "Bluetooth is off. Turn it on and try again."
            return
        }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            status.text = "BLE scanner is unavailable on this phone."
            return
        }
        found.clear()
        renderResults()
        try {
            scanner?.startScan(null,
                ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),
                callback)
            status.text = "Scanning for 12 seconds… Keep the band awake and nearby."
            scanButton.isEnabled = false
            handler.postDelayed({
                stopScan()
                status.text = "Scan finished. Select the Redmi/Mi Band entry from the results in the next development stage."
                scanButton.isEnabled = true
            }, 12_000)
        } catch (e: SecurityException) {
            status.text = "Bluetooth permission was denied."
            scanButton.isEnabled = true
        } catch (e: Exception) {
            status.text = "Could not start scan: ${e.message}"
            scanButton.isEnabled = true
        }
    }

    private fun stopScan() {
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
    }

    private fun renderResults() {
        results.text = if (found.isEmpty()) "Searching… No devices detected yet." else
            found.values.joinToString(separator = "\n\n")
    }

    override fun onDestroy() {
        stopScan()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
