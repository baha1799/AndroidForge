# Band 5 Control (Mi Smart Band 5)

Minimal native Android app (Kotlin, no dependencies) that talks to a Mi Smart Band 5 over BLE.

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a phone (Android 8+), or Build > Build APK(s).

## Use
1. Get your band's 32-hex-character auth key (modded Mi Fit method or token script).
2. Close/force-stop any other app that talks to the band; make sure Bluetooth is on.
3. Paste the key, tap "Scan & connect", pick the band.

## Features
Battery, steps, on-demand heart rate, vibrate/find band, test text notification, time sync.

## Status
Untested on real hardware. Auth uses the Huami v2 flow (0x82/0x83 + AES-128-ECB).
Notification and time-sync byte formats are experimental. The log box shows raw replies for debugging.
