package com.baha.miband5

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

/**
 * Minimal Huami/Mi Band 5 GATT client: authenticates with the 16-byte secret key,
 * then offers battery, steps, heart rate, vibrate, text notification and time sync.
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BandGatt(private val ctx: Context, private val key: ByteArray, private val cb: Callbacks) {

    interface Callbacks {
        fun log(msg: String)
        fun onAuthenticated()
        fun onDisconnected()
        fun onBattery(level: Int, charging: Boolean)
        fun onSteps(steps: Int)
        fun onHeartRate(bpm: Int)
    }

    companion object {
        private fun huami(id: Int) =
            UUID.fromString(String.format(Locale.ROOT, "0000%04x-0000-3512-2118-0009af100700", id))
        private fun std(id: Int) =
            UUID.fromString(String.format(Locale.ROOT, "0000%04x-0000-1000-8000-00805f9b34fb", id))

        val AUTH = huami(0x0009)
        val BATTERY = huami(0x0006)
        val STEPS = huami(0x0007)
        val HR_CTRL = std(0x2A39)
        val HR_MEAS = std(0x2A37)
        val ALERT_LEVEL = std(0x2A06)
        val NEW_ALERT = std(0x2A46)
        val CUR_TIME = std(0x2A2B)
        val CCCD = std(0x2902)
    }

    private val main = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private val queue = java.util.LinkedList<() -> Boolean>()
    private var busy = false
    var authenticated = false
        private set
    private var hrActive = false

    // ---------- connection ----------
    fun connect(device: BluetoothDevice) {
        cb.log("Connecting to ${device.address}…")
        gatt = device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        hrActive = false
        queue.clear(); busy = false; authenticated = false
        gatt?.disconnect()
    }

    // ---------- serialized GATT operations ----------
    private fun enqueue(op: () -> Boolean) {
        main.post { queue.add(op); pump() }
    }

    private fun pump() {
        if (busy) return
        val op = queue.poll() ?: return
        busy = true
        if (!op()) { busy = false; pump() }
    }

    private fun done() { main.post { busy = false; pump() } }

    private fun ch(uuid: UUID): BluetoothGattCharacteristic? =
        gatt?.services?.firstNotNullOfOrNull { it.getCharacteristic(uuid) }

    private fun write(uuid: UUID, data: ByteArray) = enqueue {
        val c = ch(uuid)
        if (c == null) { cb.log("Characteristic missing: $uuid"); false } else {
            c.writeType =
                if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0)
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            c.value = data
            gatt?.writeCharacteristic(c) ?: false
        }
    }

    private fun read(uuid: UUID) = enqueue {
        val c = ch(uuid)
        if (c == null) { cb.log("Characteristic missing: $uuid"); false }
        else gatt?.readCharacteristic(c) ?: false
    }

    private fun subscribe(uuid: UUID) = enqueue {
        val c = ch(uuid)
        val d = c?.getDescriptor(CCCD)
        if (c == null || d == null) { cb.log("Cannot subscribe: $uuid"); false } else {
            gatt?.setCharacteristicNotification(c, true)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt?.writeDescriptor(d) ?: false
        }
    }

    // ---------- GATT callbacks ----------
    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                cb.log("Connected, discovering services…")
                main.post { g.discoverServices() }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                main.post {
                    authenticated = false; hrActive = false
                    queue.clear(); busy = false
                    g.close()
                    cb.log("Disconnected (status $status)")
                    cb.onDisconnected()
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            main.post {
                cb.log("Services found, authenticating…")
                subscribe(AUTH)
                write(AUTH, byteArrayOf(0x82.toByte(), 0x00)) // request random number
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            val v = c.value ?: byteArrayOf()
            main.post { handleValue(c.uuid, v) }
            done()
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) cb.log("Write to ${c.uuid.toString().take(8)} failed ($status)")
            done()
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) = done()

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            main.post { handleValue(c.uuid, v) }
        }
    }

    // ---------- incoming data ----------
    private fun handleValue(uuid: UUID, v: ByteArray) {
        when (uuid) {
            AUTH -> handleAuth(v)
            BATTERY -> if (v.size >= 3) cb.onBattery(v[1].toInt() and 0xff, v[2].toInt() == 1)
            STEPS -> if (v.size >= 3) cb.onSteps((v[1].toInt() and 0xff) or ((v[2].toInt() and 0xff) shl 8))
            HR_MEAS -> if (v.size >= 2 && (v[1].toInt() and 0xff) > 0) cb.onHeartRate(v[1].toInt() and 0xff)
            else -> cb.log("Data ${uuid.toString().take(8)}: ${hex(v)}")
        }
    }

    private fun handleAuth(v: ByteArray) {
        if (v.size < 3 || v[0] != 0x10.toByte()) { cb.log("Auth message: ${hex(v)}"); return }
        val cmd = v[1].toInt() and 0xff
        val ok = v[2] == 0x01.toByte()
        when {
            cmd == 0x82 && ok && v.size >= 19 -> {
                val random = v.copyOfRange(3, 19)
                val cipher = Cipher.getInstance("AES/ECB/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))
                write(AUTH, byteArrayOf(0x83.toByte(), 0x00) + cipher.doFinal(random))
            }
            cmd == 0x83 && ok -> {
                authenticated = true
                cb.log("Authenticated ✔")
                cb.onAuthenticated()
                subscribe(HR_MEAS)
                readBattery(); readSteps()
            }
            else -> cb.log("Auth failed: ${hex(v)} (wrong key, or band still bound to another app?)")
        }
    }

    // ---------- features ----------
    private fun need(): Boolean { if (!authenticated) cb.log("Not authenticated yet"); return authenticated }

    fun readBattery() { if (need()) read(BATTERY) }
    fun readSteps() { if (need()) read(STEPS) }

    fun vibrate() { if (need()) write(ALERT_LEVEL, byteArrayOf(0x03)) }

    fun startHeartRate() {
        if (!need()) return
        hrActive = true
        write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x00))
        write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x01))
        pingHr()
    }

    fun stopHeartRate() {
        hrActive = false
        if (authenticated) write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x00))
    }

    private fun pingHr() {
        main.postDelayed({
            if (hrActive && authenticated) { write(HR_CTRL, byteArrayOf(0x16)); pingHr() }
        }, 12_000)
    }

    /** Experimental: category 0x05 (SMS/MMS) + 1 alert + UTF-8 text. */
    fun notifyText(text: String) {
        if (need()) write(NEW_ALERT, byteArrayOf(0x05, 0x01) + text.toByteArray(Charsets.UTF_8))
    }

    /** Experimental: Current Time characteristic (10 bytes) + timezone in 15-min units. */
    fun syncTime() {
        if (!need()) return
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val dow = ((cal.get(Calendar.DAY_OF_WEEK) + 5) % 7) + 1 // Mon=1 … Sun=7
        val tz = (TimeZone.getDefault().getOffset(cal.timeInMillis) / 900_000).toByte()
        write(
            CUR_TIME, byteArrayOf(
                (year and 0xff).toByte(), (year shr 8).toByte(),
                (cal.get(Calendar.MONTH) + 1).toByte(), cal.get(Calendar.DAY_OF_MONTH).toByte(),
                cal.get(Calendar.HOUR_OF_DAY).toByte(), cal.get(Calendar.MINUTE).toByte(),
                cal.get(Calendar.SECOND).toByte(), dow.toByte(), 0, 0, tz
            )
        )
    }
}
