package com.baha.miband5

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

@SuppressLint("MissingPermission")
class MainActivity : Activity(), BandGatt.Callbacks {

    private lateinit var keyInput: EditText
    private lateinit var status: TextView
    private lateinit var battery: TextView
    private lateinit var steps: TextView
    private lateinit var heart: TextView
    private lateinit var logView: TextView
    private var band: BandGatt? = null
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("band5", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        fun label(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; if (bold) setTypeface(null, Typeface.BOLD)
        }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { onClick() }
        }

        root.addView(label("Mi Smart Band 5", 22f, true))
        keyInput = EditText(this).apply {
            hint = "Auth key (32 hex characters)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setText(prefs.getString("key", ""))
        }
        root.addView(keyInput)
        root.addView(button("Scan & connect") { withPermissions { scanAndPick() } })
        root.addView(button("Reconnect to last band") { withPermissions { connectSaved() } })
        root.addView(button("Disconnect") { band?.disconnect() })

        status = label("Status: disconnected"); battery = label("Battery: –")
        steps = label("Steps: –"); heart = label("Heart rate: –")
        listOf(status, battery, steps, heart).forEach { root.addView(it) }

        root.addView(button("Refresh battery & steps") { band?.readBattery(); band?.readSteps() })
        root.addView(button("Start heart-rate measurement") { band?.startHeartRate() })
        root.addView(button("Stop heart-rate measurement") { band?.stopHeartRate() })
        root.addView(button("Vibrate / find band") { band?.vibrate() })
        root.addView(button("Send test notification") { band?.notifyText("Hello from Band 5 Control") })
        root.addView(button("Sync time") { band?.syncTime() })

        logView = TextView(this).apply { textSize = 12f; typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        root.addView(label("Log", 14f, true)); root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ---------- permissions ----------
    private var pending: (() -> Unit)? = null

    private fun withPermissions(action: () -> Unit) {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) action()
        else { pending = action; requestPermissions(needed, 1) }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) pending?.invoke()
        else log("Bluetooth permission denied")
        pending = null
    }

    // ---------- scanning / connecting ----------
    private fun parseKey(): ByteArray? {
        val s = keyInput.text.toString().replace("0x", "").replace(Regex("[^0-9a-fA-F]"), "")
        if (s.length != 32) { log("Key must be 32 hex characters (got ${s.length})"); return null }
        prefs.edit().putString("key", s).apply()
        return ByteArray(16) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    private fun scanAndPick() {
        if (parseKey() == null) return
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { log("Turn Bluetooth on first"); return }
        val found = LinkedHashMap<String, Pair<String, BluetoothDevice>>()
        val scanner = adapter.bluetoothLeScanner
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                val name = r.device.name ?: r.scanRecord?.deviceName ?: return
                found[r.device.address] = name to r.device
            }
        }
        log("Scanning for 8 s… (close the old app, keep the band awake near the phone)")
        scanner.startScan(cb)
        ui.postDelayed({
            scanner.stopScan(cb)
            val list = found.values.sortedByDescending { it.first.contains("Band", true) || it.first.contains("Mi", true) }
            if (list.isEmpty()) { log("No named BLE devices found"); return@postDelayed }
            AlertDialog.Builder(this).setTitle("Choose your band")
                .setItems(list.map { "${it.first}  (${it.second.address})" }.toTypedArray()) { _, i ->
                    prefs.edit().putString("mac", list[i].second.address).apply()
                    connect(list[i].second)
                }.show()
        }, 8000)
    }

    private fun connectSaved() {
        val mac = prefs.getString("mac", null) ?: return log("No saved band yet — use Scan & connect")
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        connect(adapter.getRemoteDevice(mac))
    }

    private fun connect(device: BluetoothDevice) {
        val key = parseKey() ?: return
        band?.disconnect()
        band = BandGatt(this, key, this).also { it.connect(device) }
        setStatus("connecting…")
    }

    // ---------- BandGatt.Callbacks ----------
    private fun setStatus(s: String) = runOnUiThread { status.text = "Status: $s" }
    override fun log(msg: String) = runOnUiThread { logView.append(msg + "\n") }
    override fun onAuthenticated() = setStatus("connected & authenticated")
    override fun onDisconnected() = setStatus("disconnected")
    override fun onBattery(level: Int, charging: Boolean) =
        runOnUiThread { battery.text = "Battery: $level%" + if (charging) " (charging)" else "" }
    override fun onSteps(steps: Int) = runOnUiThread { this.steps.text = "Steps: $steps" }
    override fun onHeartRate(bpm: Int) = runOnUiThread { heart.text = "Heart rate: $bpm bpm" }

    override fun onDestroy() { band?.disconnect(); super.onDestroy() }
}
