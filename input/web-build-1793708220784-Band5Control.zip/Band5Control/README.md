# Band 5 Control (Mi Smart Band 5)

Native Android app (Kotlin + Jetpack Compose) that talks to a Mi Smart Band 5 over BLE.

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a phone (Android 8+), or Build > Build APK(s).

## Structure (scalable by design)
- `BandGatt.kt` - low-level BLE: auth, battery/steps/HR, vibrate, notify, time sync,
  and an experimental watchface/firmware uploader.
- `BandViewModel.kt` - holds connection state as a `StateFlow<BandUiState>` that any
  screen can observe; `AppSection` enum is the registry of tabs. Add a new tab by:
  1. adding an entry to `AppSection`
  2. adding a `when` branch + NavigationBarItem in `MainActivity.kt`
  3. writing a new Composable screen in `ui/`
- `ui/DashboardScreen.kt` - connection status, battery, steps, heart rate, vibrate,
  test notification, time sync, and a live log.
- `ui/WatchfacesScreen.kt` - in-app browser to find a watchface file on a gallery
  site, a file picker for the downloaded `.bin`, and an "Install to band" button.

## Watchface install - status: EXPERIMENTAL
The upload protocol (FW_CONTROL / FW_DATA characteristics) is a best-effort
reconstruction from public documentation, not verified against a reference
implementation's source. It is very likely the exact command bytes
(`FILE_TYPE_WATCHFACE`, the start-packet format) will need adjusting once we see
the band's real notification replies - the in-app log shows every raw reply in hex
for exactly this purpose. Watchfaces are low-risk to experiment with: a malformed
file should simply be rejected by the band rather than bricking it (unlike
flashing firmware). If it doesn't work after a round of tweaking, Gadgetbridge
(from F-Droid) already implements this reliably and can be used just for
watchface installs while this app handles everything else.

## Getting the auth key
See prior conversation notes - either from Zepp's cloud (browser console script
against watchface.zepp.com), from Zepp Life's own log files, or on a rooted phone
from its database. Don't unpair the band from the vendor app or it invalidates
the key.
