package com.baha.miband5

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

/**
 * Minimal Huami/Mi Band 5 GATT client: authenticates with the 16-byte secret key,
 * then offers battery, steps, heart rate, vibrate, text notification and time sync.
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BandGatt(private val ctx: Context, private val key: ByteArray, private val cb: Callbacks) {

    interface Callbacks {
        fun log(msg: String)
        fun onAuthenticated()
        fun onDisconnected()
        fun onBattery(level: Int, charging: Boolean)
        fun onSteps(steps: Int)
        fun onHeartRate(bpm: Int)
    }

    companion object {
        private fun huami(id: Int) =
            UUID.fromString(String.format(Locale.ROOT, "0000%04x-0000-3512-2118-0009af100700", id))
        private fun std(id: Int) =
            UUID.fromString(String.format(Locale.ROOT, "0000%04x-0000-1000-8000-00805f9b34fb", id))

        val AUTH = huami(0x0009)
        val BATTERY = huami(0x0006)
        val STEPS = huami(0x0007)
        val HR_CTRL = std(0x2A39)
        val HR_MEAS = std(0x2A37)
        val ALERT_LEVEL = std(0x2A06)
        val NEW_ALERT = std(0x2A46)
        val CUR_TIME = std(0x2A2B)
        val CCCD = std(0x2902)

        // Firmware/watchface upload service - EXPERIMENTAL, reconstructed from public
        // documentation of the Huami OTA protocol, not verified against real firmware source.
        val FW_CONTROL = huami(0x1531)
        val FW_DATA = huami(0x1532)

        const val FILE_TYPE_FIRMWARE = 0
        const val FILE_TYPE_RESOURCE = 1
        const val FILE_TYPE_WATCHFACE = 8 // best-effort guess; adjust if band rejects it
    }

    interface InstallCallbacks {
        fun onLog(msg: String)
        fun onProgress(sentBytes: Int, totalBytes: Int)
        fun onResult(success: Boolean, message: String)
    }

    private fun crc32(data: ByteArray): Long {
        val crc = java.util.zip.CRC32()
        crc.update(data)
        return crc.value
    }

    private fun le32(v: Int) = byteArrayOf(
        (v and 0xff).toByte(), ((v shr 8) and 0xff).toByte(),
        ((v shr 16) and 0xff).toByte(), ((v shr 24) and 0xff).toByte()
    )

    /**
     * Upload a firmware/watchface/resource file to the band over the FW_CONTROL + FW_DATA
     * characteristics. EXPERIMENTAL: the exact command bytes are a best-effort reconstruction
     * and may need adjusting once we see the band's real notification replies (shown via
     * cb.onLog). Watchfaces are low risk to experiment with - unlike flashing firmware, a bad
     * watchface payload is normally just rejected by the band rather than bricking it.
     */
    fun installFile(data: ByteArray, fileType: Int, cb: InstallCallbacks) {
        if (!authenticated) { cb.onResult(false, "Not authenticated"); return }
        val ctrl = ch(FW_CONTROL)
        val dataChar = ch(FW_DATA)
        if (ctrl == null || dataChar == null) {
            cb.onResult(false, "Firmware service not found on this device"); return
        }

        val chunkSize = 18 // conservative; raise once a bigger MTU is confirmed negotiated
        var offset = 0
        var awaitingStartAck = true
        val crc = crc32(data)

        // Re-use the shared notify path: listen for FW_CONTROL notifications via a one-off hook.
        notifyHook = { uuid, value ->
            if (uuid == FW_CONTROL) {
                cb.onLog("FW_CONTROL notify: ${hex(value)}")
                if (awaitingStartAck) {
                    awaitingStartAck = false
                    if (value.size >= 3 && value[0] == 0x10.toByte() && value[2] == 0x01.toByte()) {
                        sendNextChunk(dataChar, data, offset, chunkSize, ctrl, cb) { newOffset ->
                            offset = newOffset
                        }
                    } else {
                        cb.onResult(false, "Band rejected start command: ${hex(value)}")
                        notifyHook = null
                    }
                } else {
                    // Final "apply" ack.
                    val ok = value.size >= 3 && value[2] == 0x01.toByte()
                    cb.onResult(ok, if (ok) "Install acknowledged by band" else "Band reported failure: ${hex(value)}")
                    notifyHook = null
                }
            }
        }

        enqueue {
            gatt?.setCharacteristicNotification(ctrl, true)
            val d = ctrl.getDescriptor(CCCD)
            d?.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            d?.let { gatt?.writeDescriptor(it) } ?: false
        }
        // Start command: [0x01, 0x08, 0x00, 0x01, type, size(LE32), crc32(LE32)]
        val start = byteArrayOf(0x01, 0x08, 0x00, 0x01, fileType.toByte()) + le32(data.size) + le32(crc.toInt())
        cb.onLog("Sending start command: ${hex(start)}")
        write(FW_CONTROL, start)
    }

    private fun sendNextChunk(
        dataChar: BluetoothGattCharacteristic, data: ByteArray, offset: Int, chunkSize: Int,
        ctrl: BluetoothGattCharacteristic, cb: InstallCallbacks, setOffset: (Int) -> Unit
    ) {
        if (offset >= data.size) {
            cb.onLog("All bytes sent, requesting apply…")
            write(FW_CONTROL, byteArrayOf(0x02, 0x01.toByte()))
            return
        }
        val end = minOf(offset + chunkSize, data.size)
        val chunk = data.copyOfRange(offset, end)
        enqueue {
            dataChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            dataChar.value = chunk
            gatt?.writeCharacteristic(dataChar) ?: false
        }
        cb.onProgress(end, data.size)
        main.postDelayed({ sendNextChunk(dataChar, data, end, chunkSize, ctrl, cb, setOffset) }, 15)
        setOffset(end)
    }

    // Lets installFile() intercept notifications without disturbing the main handleValue() path.
    private var notifyHook: ((UUID, ByteArray) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private val queue = java.util.LinkedList<() -> Boolean>()
    private var busy = false
    var authenticated = false
        private set
    private var hrActive = false

    // ---------- connection ----------
    fun connect(device: BluetoothDevice) {
        cb.log("Connecting to ${device.address}…")
        gatt = device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        hrActive = false
        queue.clear(); busy = false; authenticated = false
        gatt?.disconnect()
    }

    // ---------- serialized GATT operations ----------
    private fun enqueue(op: () -> Boolean) {
        main.post { queue.add(op); pump() }
    }

    private fun pump() {
        if (busy) return
        val op = queue.poll() ?: return
        busy = true
        if (!op()) { busy = false; pump() }
    }

    private fun done() { main.post { busy = false; pump() } }

    private fun ch(uuid: UUID): BluetoothGattCharacteristic? =
        gatt?.services?.firstNotNullOfOrNull { it.getCharacteristic(uuid) }

    private fun write(uuid: UUID, data: ByteArray) = enqueue {
        val c = ch(uuid)
        if (c == null) { cb.log("Characteristic missing: $uuid"); false } else {
            c.writeType =
                if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0)
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            c.value = data
            gatt?.writeCharacteristic(c) ?: false
        }
    }

    private fun read(uuid: UUID) = enqueue {
        val c = ch(uuid)
        if (c == null) { cb.log("Characteristic missing: $uuid"); false }
        else gatt?.readCharacteristic(c) ?: false
    }

    private fun subscribe(uuid: UUID) = enqueue {
        val c = ch(uuid)
        val d = c?.getDescriptor(CCCD)
        if (c == null || d == null) { cb.log("Cannot subscribe: $uuid"); false } else {
            gatt?.setCharacteristicNotification(c, true)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt?.writeDescriptor(d) ?: false
        }
    }

    // ---------- GATT callbacks ----------
    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                cb.log("Connected, discovering services…")
                main.post { g.discoverServices() }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                main.post {
                    authenticated = false; hrActive = false
                    queue.clear(); busy = false
                    g.close()
                    cb.log("Disconnected (status $status)")
                    cb.onDisconnected()
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            main.post {
                cb.log("Services found, authenticating…")
                subscribe(AUTH)
                write(AUTH, byteArrayOf(0x82.toByte(), 0x00)) // request random number
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            val v = c.value ?: byteArrayOf()
            main.post { handleValue(c.uuid, v) }
            done()
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) cb.log("Write to ${c.uuid.toString().take(8)} failed ($status)")
            done()
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) = done()

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            main.post { handleValue(c.uuid, v) }
        }
    }

    // ---------- incoming data ----------
    private fun handleValue(uuid: UUID, v: ByteArray) {
        notifyHook?.let { it(uuid, v); if (uuid == FW_CONTROL) return }
        when (uuid) {
            AUTH -> handleAuth(v)
            BATTERY -> if (v.size >= 3) cb.onBattery(v[1].toInt() and 0xff, v[2].toInt() == 1)
            STEPS -> if (v.size >= 3) cb.onSteps((v[1].toInt() and 0xff) or ((v[2].toInt() and 0xff) shl 8))
            HR_MEAS -> if (v.size >= 2 && (v[1].toInt() and 0xff) > 0) cb.onHeartRate(v[1].toInt() and 0xff)
            else -> cb.log("Data ${uuid.toString().take(8)}: ${hex(v)}")
        }
    }

    private fun handleAuth(v: ByteArray) {
        if (v.size < 3 || v[0] != 0x10.toByte()) { cb.log("Auth message: ${hex(v)}"); return }
        val cmd = v[1].toInt() and 0xff
        val ok = v[2] == 0x01.toByte()
        when {
            cmd == 0x82 && ok && v.size >= 19 -> {
                val random = v.copyOfRange(3, 19)
                val cipher = Cipher.getInstance("AES/ECB/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))
                write(AUTH, byteArrayOf(0x83.toByte(), 0x00) + cipher.doFinal(random))
            }
            cmd == 0x83 && ok -> {
                authenticated = true
                cb.log("Authenticated ✔")
                cb.onAuthenticated()
                subscribe(HR_MEAS)
                readBattery(); readSteps()
            }
            else -> cb.log("Auth failed: ${hex(v)} (wrong key, or band still bound to another app?)")
        }
    }

    // ---------- features ----------
    private fun need(): Boolean { if (!authenticated) cb.log("Not authenticated yet"); return authenticated }

    fun readBattery() { if (need()) read(BATTERY) }
    fun readSteps() { if (need()) read(STEPS) }

    fun vibrate() { if (need()) write(ALERT_LEVEL, byteArrayOf(0x03)) }

    fun startHeartRate() {
        if (!need()) return
        hrActive = true
        write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x00))
        write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x01))
        pingHr()
    }

    fun stopHeartRate() {
        hrActive = false
        if (authenticated) write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x00))
    }

    private fun pingHr() {
        main.postDelayed({
            if (hrActive && authenticated) { write(HR_CTRL, byteArrayOf(0x16)); pingHr() }
        }, 12_000)
    }

    /** Experimental: category 0x05 (SMS/MMS) + 1 alert + UTF-8 text. */
    fun notifyText(text: String) {
        if (need()) write(NEW_ALERT, byteArrayOf(0x05, 0x01) + text.toByteArray(Charsets.UTF_8))
    }

    /** Experimental: Current Time characteristic (10 bytes) + timezone in 15-min units. */
    fun syncTime() {
        if (!need()) return
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val dow = ((cal.get(Calendar.DAY_OF_WEEK) + 5) % 7) + 1 // Mon=1 … Sun=7
        val tz = (TimeZone.getDefault().getOffset(cal.timeInMillis) / 900_000).toByte()
        write(
            CUR_TIME, byteArrayOf(
                (year and 0xff).toByte(), (year shr 8).toByte(),
                (cal.get(Calendar.MONTH) + 1).toByte(), cal.get(Calendar.DAY_OF_MONTH).toByte(),
                cal.get(Calendar.HOUR_OF_DAY).toByte(), cal.get(Calendar.MINUTE).toByte(),
                cal.get(Calendar.SECOND).toByte(), dow.toByte(), 0, 0, tz
            )
        )
    }
}
