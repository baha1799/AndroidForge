package com.baha.miband5

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.baha.miband5.ui.DashboardScreen
import com.baha.miband5.ui.WatchfacesScreen

@SuppressLint("MissingPermission")
class MainActivity : ComponentActivity() {

    private val vm: BandViewModel by viewModels()
    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) pendingAction?.invoke()
        pendingAction = null
    }

    private fun withBtPermissions(action: () -> Unit) {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) action()
        else { pendingAction = action; permissionLauncher.launch(needed) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                AppRoot(vm) { onPicked ->
                    withBtPermissions { scanForDevices(onPicked) }
                }
            }
        }
    }

    private fun scanForDevices(onPicked: (BluetoothDevice) -> Unit) {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) return
        val found = LinkedHashMap<String, BluetoothDevice>()
        val scanner = adapter.bluetoothLeScanner
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                r.device.name?.let { found[r.device.address] = r.device }
            }
        }
        scanner.startScan(cb)
        android.os.Handler(mainLooper).postDelayed({
            scanner.stopScan(cb)
            found.values.firstOrNull { it.name?.contains("Mi", true) == true || it.name?.contains("Band", true) == true }
                ?.let(onPicked) ?: found.values.firstOrNull()?.let(onPicked)
        }, 8000)
    }
}

@Composable
private fun AppRoot(vm: BandViewModel, onScan: ((BluetoothDevice) -> Unit) -> Unit) {
    var section by remember { mutableStateOf(AppSection.DASHBOARD) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = section == AppSection.DASHBOARD,
                    onClick = { section = AppSection.DASHBOARD },
                    icon = { Icon(Icons.Default.Dashboard, null) },
                    label = { Text(AppSection.DASHBOARD.label) }
                )
                NavigationBarItem(
                    selected = section == AppSection.WATCHFACES,
                    onClick = { section = AppSection.WATCHFACES },
                    icon = { Icon(Icons.Default.Watch, null) },
                    label = { Text(AppSection.WATCHFACES.label) }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (section) {
                AppSection.DASHBOARD -> DashboardScreen(vm) {
                    onScan { device -> vm.connect(device, vm.savedKeyHex()) }
                }
                AppSection.WATCHFACES -> WatchfacesScreen(vm)
            }
        }
    }
}
