package com.baha.miband5.ui

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.baha.miband5.BandViewModel

@Composable
fun WatchfacesScreen(vm: BandViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var urlField by remember { mutableStateOf("https://amazfitwatchfaces.com/") }
    var showBrowser by remember { mutableStateOf(false) }
    var pickedFileName by remember { mutableStateOf<String?>(null) }
    var pickedBytes by remember { mutableStateOf<ByteArray?>(null) }
    var showConfirm by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        context.contentResolver.openInputStream(uri)?.use { stream ->
            pickedBytes = stream.readBytes()
            pickedFileName = uri.lastPathSegment ?: "watchface file"
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("1. Find a watchface", fontWeight = FontWeight.Bold)
        Text(
            "Browse a gallery site below, or open one in your own browser. Download the .bin " +
            "file for the Mi Band 5 / Mi Band 4 (same firmware family), it will land in Downloads.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = urlField, onValueChange = { urlField = it },
            label = { Text("Gallery URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Button(onClick = { showBrowser = true }, modifier = Modifier.fillMaxWidth()) { Text("Open browser") }

        Divider()

        Text("2. Pick the downloaded file", fontWeight = FontWeight.Bold)
        OutlinedButton(
            onClick = { filePicker.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth()
        ) { Text(pickedFileName ?: "Choose watchface file…") }
        pickedBytes?.let { Text("${it.size} bytes ready to install", style = MaterialTheme.typography.bodySmall) }

        Divider()

        Text("3. Install", fontWeight = FontWeight.Bold)
        Text(
            "Experimental: the band's reply is logged below. If it doesn't work, tell Claude " +
            "the exact log lines and we'll adjust the protocol - or fall back to Gadgetbridge for this step.",
            style = MaterialTheme.typography.bodySmall
        )
        Button(
            onClick = { showConfirm = true },
            enabled = pickedBytes != null && state.connected && state.installProgress == null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Install to band") }

        state.installProgress?.let { p ->
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
            Text("${(p * 100).toInt()}%")
        }
        state.installMessage?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }

        Divider()
        Text("Log", fontWeight = FontWeight.Bold)
        LogView(state.log)
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("Install watchface?") },
            text = { Text(
                "This sends ${pickedFileName} to the band over Bluetooth using an experimental " +
                "upload protocol. Watchfaces are low-risk compared to firmware - a bad file is " +
                "normally just rejected, not something that bricks the band - but it's untested. Continue?"
            ) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    pickedBytes?.let { vm.installWatchface(it) }
                }) { Text("Install") }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("Cancel") } }
        )
    }

    if (showBrowser) {
        AlertDialog(
            onDismissRequest = { showBrowser = false },
            title = { Text("Watchface browser") },
            text = {
                AndroidView(
                    modifier = Modifier.fillMaxWidth().height(480.dp),
                    factory = { ctx -> buildWebView(ctx, urlField) }
                )
            },
            confirmButton = { TextButton(onClick = { showBrowser = false }) { Text("Close") } }
        )
    }
}

private fun buildWebView(ctx: Context, startUrl: String): WebView = WebView(ctx).apply {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    webViewClient = WebViewClient()
    setDownloadListener { url, _, contentDisposition, mimeType, _ ->
        val request = DownloadManager.Request(Uri.parse(url))
            .setMimeType(mimeType)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(
                android.os.Environment.DIRECTORY_DOWNLOADS,
                Uri.parse(url).lastPathSegment ?: "watchface.bin"
            )
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
    }
    loadUrl(startUrl)
}
