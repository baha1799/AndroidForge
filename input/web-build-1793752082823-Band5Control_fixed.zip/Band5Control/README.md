# Band 5 Control (Mi Smart Band 5)

Native Android app (Kotlin + Jetpack Compose) that talks to a Mi Smart Band 5 over BLE.

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a phone (Android 8+), or Build > Build APK(s).

## Structure (scalable by design)
- `BandGatt.kt` - low-level BLE: auth, battery/steps/HR, vibrate, notify, time sync,
  and a Mi Band 5 watchface uploader.
- `BandViewModel.kt` - holds connection state as a `StateFlow<BandUiState>` that any
  screen can observe; `AppSection` enum is the registry of tabs. Add a new tab by:
  1. adding an entry to `AppSection`
  2. adding a `when` branch + NavigationBarItem in `MainActivity.kt`
  3. writing a new Composable screen in `ui/`
- `ui/DashboardScreen.kt` - connection status, battery, steps, heart rate, vibrate,
  test notification, time sync, and a live log.
- `ui/WatchfacesScreen.kt` - in-app browser to find a watchface file on a gallery
  site, a file picker for the downloaded `.bin`, and an "Install to band" button.

## Watchface install
The Mi Band 5 transfer sequence was captured from a successful Zepp Life sync and
is implemented in `BandGatt.kt`. It negotiates MTU 247, prepares the transfer,
sends a four-byte size and CRC-32 in INIT, then streams the `.bin` payload and
checks the band acknowledgements. Watchface compatibility and slot replacement
still depend on the `.bin` file and its watchface ID. The observed sequence is
documented in `FirmwareAnalysis/mi-band5-firmware-findings.md`.

## Watchface catalog
The in-app community catalog follows the site's Fresh, Top, and Updated pagination
with a Load next page button. Zepp Life does not provide a public Mi Band 5
watchface catalog API for third-party apps; use Import Zepp Life face to select an
official `.bin` you have downloaded or copied to an accessible folder.

## Getting the auth key
See prior conversation notes - either from Zepp's cloud (browser console script
against watchface.zepp.com), from Zepp Life's own log files, or on a rooted phone
from its database. Don't unpair the band from the vendor app or it invalidates
the key.
