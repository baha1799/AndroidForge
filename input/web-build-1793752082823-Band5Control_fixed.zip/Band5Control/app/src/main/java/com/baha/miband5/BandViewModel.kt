package com.baha.miband5

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class BandUiState(
    val connected: Boolean = false,
    val statusText: String = "Disconnected",
    val battery: Int? = null,
    val charging: Boolean = false,
    val steps: Int? = null,
    val heartRate: Int? = null,
    val log: List<String> = emptyList(),
    val installProgress: Float? = null, // null = no install in progress
    val installMessage: String? = null
)

/** Registry of app sections, so adding a new tab later means adding one entry here. */
enum class AppSection(val label: String) {
    DASHBOARD("Dashboard"),
    WATCHFACES("Watchfaces"),
    // Add future sections here, e.g. ALARMS("Alarms"), NOTIFICATIONS("Notifications")
}

class BandViewModel(app: Application) : AndroidViewModel(app), BandGatt.Callbacks {

    private val prefs = app.getSharedPreferences("band5", Application.MODE_PRIVATE)
    private val _state = MutableStateFlow(BandUiState())
    val state: StateFlow<BandUiState> = _state

    private var band: BandGatt? = null

    fun savedMac(): String? = prefs.getString("mac", null)
    fun savedKeyHex(): String = prefs.getString("key", "") ?: ""
    fun hasSavedBand(): Boolean = !savedMac().isNullOrBlank() && savedKeyHex().isNotBlank()

    fun parseKey(hex: String): ByteArray? {
        val s = hex.replace("0x", "", ignoreCase = true).replace(Regex("[^0-9a-fA-F]"), "")
        if (s.length != 32) { appendLog("Key must be 32 hex characters (got ${s.length})"); return null }
        prefs.edit().putString("key", s).apply()
        return ByteArray(16) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    fun connect(device: BluetoothDevice, keyHex: String) {
        val key = parseKey(keyHex) ?: return
        prefs.edit().putString("mac", device.address).apply()
        band?.disconnect()
        _state.update { it.copy(statusText = "Connecting…") }
        band = BandGatt(getApplication(), key, this).also { it.connect(device) }
    }

    fun reconnectSaved(): Boolean {
        val mac = savedMac() ?: run { appendLog("No saved band address; use Scan & connect first"); return false }
        val adapter = (getApplication<Application>().getSystemService(Application.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val device = adapter.getRemoteDevice(mac)
        connect(device, savedKeyHex())
        return true
    }

    fun disconnect() = band?.disconnect()
    fun refresh() { band?.readBattery(); band?.readSteps() }
    fun startHeartRate() = band?.startHeartRate()
    fun stopHeartRate() = band?.stopHeartRate()
    fun vibrate() = band?.vibrate()
    fun sendTestNotification() = band?.notifyText("Hello from Band 5 Control")
    fun syncTime() = band?.syncTime()

    fun installWatchface(bytes: ByteArray) {
        val b = band ?: run { appendLog("Not connected"); return }
        _state.update { it.copy(installProgress = 0f, installMessage = "Starting…") }
        b.installFile(bytes, BandGatt.FILE_TYPE_WATCHFACE, object : BandGatt.InstallCallbacks {
            override fun onLog(msg: String) = appendLog(msg)
            override fun onProgress(sentBytes: Int, totalBytes: Int) {
                _state.update { it.copy(installProgress = sentBytes.toFloat() / totalBytes) }
            }
            override fun onResult(success: Boolean, message: String) {
                _state.update { it.copy(installProgress = null, installMessage = message) }
                appendLog(if (success) "Install succeeded: $message" else "Install failed: $message")
            }
        })
    }

    private fun appendLog(msg: String) = _state.update { it.copy(log = (it.log + msg).takeLast(200)) }

    // ---------- BandGatt.Callbacks ----------
    override fun log(msg: String) = appendLog(msg)
    override fun onAuthenticated() = _state.update { it.copy(connected = true, statusText = "Connected & authenticated") }
    override fun onDisconnected() = _state.update { it.copy(connected = false, statusText = "Disconnected", heartRate = null) }
    override fun onBattery(level: Int, charging: Boolean) = _state.update { it.copy(battery = level, charging = charging) }
    override fun onSteps(steps: Int) = _state.update { it.copy(steps = steps) }
    override fun onHeartRate(bpm: Int) = _state.update { it.copy(heartRate = bpm) }

    override fun onCleared() { band?.disconnect(); super.onCleared() }
}
