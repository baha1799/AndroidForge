package com.baha.miband5

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.baha.miband5.ui.DashboardScreen
import com.baha.miband5.ui.NativeWatchfaceShop

@SuppressLint("MissingPermission")
class MainActivity : ComponentActivity() {

    private val vm: BandViewModel by viewModels()
    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) pendingAction?.invoke()
        else vm.log("Bluetooth permission denied; allow Bluetooth access in Android Settings")
        pendingAction = null
    }

    private fun withBtPermissions(action: () -> Unit) {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) action()
        else { pendingAction = action; permissionLauncher.launch(needed) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                AppRoot(
                    vm = vm,
                    onScan = { onPicked -> withBtPermissions { scanForDevices(onPicked) } },
                    onReconnect = { withBtPermissions { vm.reconnectSaved() } }
                )
            }
        }
        if (savedInstanceState == null && vm.hasSavedBand()) {
            window.decorView.post {
                vm.log("Auto-connecting to saved band…")
                withBtPermissions { vm.reconnectSaved() }
            }
        }
    }

    private fun scanForDevices(onPicked: (BluetoothDevice) -> Unit) {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null) { vm.log("Bluetooth adapter unavailable"); return }
        if (!adapter.isEnabled) { vm.log("Bluetooth is off; turn it on and try again"); return }
        val found = LinkedHashMap<String, BluetoothDevice>()
        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) { vm.log("BLE scanner unavailable"); return }
        val cb = object : ScanCallback() {
            override fun onScanResult(type: Int, r: ScanResult) {
                r.device.name?.let { found[r.device.address] = r.device }
            }

            override fun onScanFailed(errorCode: Int) {
                vm.log("BLE scan failed ($errorCode)")
            }
        }
        vm.log("Scanning for nearby bands for 8 seconds…")
        scanner.startScan(cb)
        android.os.Handler(mainLooper).postDelayed({
            scanner.stopScan(cb)
            val device = found.values.firstOrNull {
                it.name?.contains("Mi", true) == true || it.name?.contains("Band", true) == true
            } ?: found.values.firstOrNull()
            if (device == null) vm.log("No named BLE devices found; keep the band nearby and awake")
            else {
                vm.log("Found ${device.name ?: "BLE device"}; connecting…")
                onPicked(device)
            }
        }, 8000)
    }
}

@Composable
private fun AppRoot(
    vm: BandViewModel,
    onScan: ((BluetoothDevice) -> Unit) -> Unit,
    onReconnect: () -> Unit
) {
    var section by remember { mutableStateOf(AppSection.DASHBOARD) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = section == AppSection.DASHBOARD,
                    onClick = { section = AppSection.DASHBOARD },
                    icon = { Icon(Icons.Default.Dashboard, null) },
                    label = { Text(AppSection.DASHBOARD.label) }
                )
                NavigationBarItem(
                    selected = section == AppSection.WATCHFACES,
                    onClick = { section = AppSection.WATCHFACES },
                    icon = { Icon(Icons.Default.Watch, null) },
                    label = { Text(AppSection.WATCHFACES.label) }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (section) {
                AppSection.DASHBOARD -> DashboardScreen(
                    vm = vm,
                    onScanRequested = { keyHex -> onScan { device -> vm.connect(device, keyHex) } },
                    onReconnectRequested = onReconnect
                )
                AppSection.WATCHFACES -> NativeWatchfaceShop(vm)
            }
        }
    }
}
