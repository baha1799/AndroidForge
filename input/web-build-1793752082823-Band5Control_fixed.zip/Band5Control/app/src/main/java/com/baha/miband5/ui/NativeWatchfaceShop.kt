package com.baha.miband5.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.foundation.background
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.baha.miband5.BandViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URL

private const val SHOP_FRESH = "https://amazfitwatchfaces.com/mi-band-5/fresh"
private const val SHOP_TOP = "https://amazfitwatchfaces.com/mi-band-5/top"
private const val SHOP_UPDATED = "https://amazfitwatchfaces.com/mi-band-5/updated"

private data class CatalogFace(
    val id: String,
    val title: String,
    val subtitle: String,
    val pageUrl: String,
    val previewUrl: String
)

private data class FaceVariant(val name: String, val url: String, val referer: String)

@Composable
fun NativeWatchfaceShop(vm: BandViewModel) {
    val state by vm.state.collectAsState()
    var faces by remember { mutableStateOf<List<CatalogFace>>(emptyList()) }
    var variants by remember { mutableStateOf<List<FaceVariant>>(emptyList()) }
    var selectedFace by remember { mutableStateOf<CatalogFace?>(null) }
    var filter by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Loading Mi Band 5 watchfaces…") }
    var nextPageUrl by remember { mutableStateOf<String?>(null) }
    var loadedPages by remember { mutableIntStateOf(0) }
    var categoryUrl by remember { mutableStateOf(SHOP_FRESH) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pickedName by remember { mutableStateOf<String?>(null) }
    var pickedBytes by remember { mutableStateOf<ByteArray?>(null) }
    val context = LocalContext.current

    val officialFacePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Could not open the selected file")
        }.onSuccess { bytes ->
            if (!isMiBand5Watchface(bytes)) {
                status = "That file is not a valid Mi Band 5 watchface (.bin)"
            } else {
                pickedBytes = bytes
                pickedName = uri.lastPathSegment?.substringAfterLast(':') ?: "Zepp-Life-watchface.bin"
                status = "Official face file ready to install (${bytes.size} bytes)"
            }
        }.onFailure { error ->
            status = "Could not read the selected file: ${error.message ?: "unknown error"}"
        }
    }

    AndroidView(
        modifier = Modifier.size(1.dp),
        factory = { ctx ->
            createCatalogReader(
                context = ctx,
                onCatalog = { found, next ->
                    faces = (faces + found).distinctBy { it.id }
                    nextPageUrl = next
                    loadedPages += 1
                    loading = false
                    status = if (faces.isEmpty()) "Catalog returned no faces; try Refresh." else "${faces.size} faces loaded across $loadedPages page${if (loadedPages == 1) "" else "s"}"
                },
                onVariants = { found ->
                    loading = false
                    variants = found
                    if (found.isEmpty()) status = "No direct .bin download found for this face"
                },
                onError = { message -> loading = false; status = message }
            ).also { webView = it }
        }
    )
    LaunchedEffect(webView) { webView?.loadUrl(categoryUrl) }

    fun loadCategory(url: String, label: String) {
        categoryUrl = url
        faces = emptyList()
        nextPageUrl = null
        loadedPages = 0
        loading = true
        status = "Loading $label watchfaces…"
        webView?.loadUrl(url)
    }

    val visibleFaces = remember(faces, filter) {
        if (filter.isBlank()) faces else faces.filter {
            it.title.contains(filter, true) || it.subtitle.contains(filter, true) || it.id.contains(filter)
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Mi Band 5 watchface shop", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Choose a face to download its .bin. Transfers use the Mi Band 5 sequence captured from Zepp Life; a face with an existing ID may replace that saved face.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = categoryUrl == SHOP_FRESH, onClick = {
                loadCategory(SHOP_FRESH, "fresh")
            }, label = { Text("Fresh") })
            FilterChip(selected = categoryUrl == SHOP_TOP, onClick = {
                loadCategory(SHOP_TOP, "top")
            }, label = { Text("Top") })
            FilterChip(selected = categoryUrl == SHOP_UPDATED, onClick = {
                loadCategory(SHOP_UPDATED, "updated")
            }, label = { Text("Updated") })
            TextButton(onClick = { loadCategory(categoryUrl, "catalog") }) { Text("Refresh") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                status = "Choose a .bin downloaded by Zepp Life. If Android hides its app folder, copy the file to Downloads first."
                officialFacePicker.launch(arrayOf("*/*"))
            }) { Text("Import Zepp Life face") }
            if (nextPageUrl != null) {
                Button(onClick = {
                    loading = true
                    status = "Loading next catalog page…"
                    webView?.loadUrl(nextPageUrl!!)
                }, enabled = !loading) { Text("Load next page") }
            }
        }
        OutlinedTextField(
            value = filter, onValueChange = { filter = it },
            label = { Text("Search loaded faces") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status, style = MaterialTheme.typography.bodySmall)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visibleFaces, key = { it.id }) { face ->
                CatalogFaceCard(face = face, onDownload = {
                    selectedFace = face
                    variants = emptyList()
                    loading = true
                    status = "Finding download versions for ${face.title}…"
                    webView?.loadUrl(face.pageUrl)
                })
            }
        }
        if (pickedName != null) Text("Ready: $pickedName (${pickedBytes?.size ?: 0} bytes)", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (pickedName != null) OutlinedButton(onClick = { pickedName = null; pickedBytes = null }) { Text("Clear") }
            Button(
                onClick = { pickedBytes?.let(vm::installWatchface) },
                enabled = pickedBytes != null && state.connected && state.installProgress == null,
                modifier = Modifier.weight(1f)
            ) { Text(if (state.connected) "Install to band" else "Connect to install") }
        }
        state.installProgress?.let { progress ->
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text("Uploading ${(progress * 100).toInt()}%")
        }
        state.installMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }

    if (variants.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { variants = emptyList() },
            title = { Text("Choose ${selectedFace?.title ?: "watchface"} version") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    variants.forEach { variant ->
                        TextButton(onClick = {
                            variants = emptyList()
                            loading = true
                            status = "Downloading ${variant.name}…"
                            downloadFace(webView, vm, variant, onProgress = { status = it }, onReady = { name, bytes ->
                                pickedName = name
                                pickedBytes = bytes
                                loading = false
                                status = "Download ready to install"
                            })
                        }, modifier = Modifier.fillMaxWidth()) { Text(variant.name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { variants = emptyList() }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun CatalogFaceCard(face: CatalogFace, onDownload: () -> Unit) {
    val preview by produceState<Bitmap?>(initialValue = null, face.previewUrl, face.pageUrl) {
        value = if (face.previewUrl.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val connection = URL(face.previewUrl).openConnection()
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                connection.setRequestProperty("Referer", face.pageUrl)
                connection.getInputStream().use { input -> BitmapFactory.decodeStream(input) }
            }.getOrNull()
        }
    }
    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(width = 58.dp, height = 72.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (preview != null) Image(
                    bitmap = preview!!.asImageBitmap(), contentDescription = face.title,
                    modifier = Modifier.fillMaxSize().padding(3.dp)
                ) else Text("⌚", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(face.title, fontWeight = FontWeight.SemiBold, maxLines = 2)
                Text(face.subtitle.ifBlank { "Mi Band 5 • #${face.id}" }, style = MaterialTheme.typography.bodySmall, maxLines = 2)
            }
            Button(onClick = onDownload) { Text("Download") }
        }
    }
}

private fun createCatalogReader(
    context: Context,
    onCatalog: (List<CatalogFace>, String?) -> Unit,
    onVariants: (List<FaceVariant>) -> Unit,
    onError: (String) -> Unit
): WebView = WebView(context).apply {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.loadsImagesAutomatically = false
    settings.blockNetworkImage = true
    webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String) {
            if (!url.contains("amazfitwatchfaces.com/mi-band-5/")) return
            if (url.contains("/view/")) {
                view.evaluateJavascript(VARIANTS_SCRIPT) { raw ->
                    val found = parseJsonArray(raw) { item ->
                        FaceVariant(item.optString("name", "Version"), item.optString("url"), url)
                    }.filter { it.url.startsWith("https://amazfitwatchfaces.com/dl/mi-band-5/bin/") }
                    onVariants(found)
                }
            } else {
                view.evaluateJavascript(CATALOG_SCRIPT) { raw ->
                    val (found, next) = parseCatalogPage(raw)
                    if (found.isEmpty()) onError("Catalog blocked or changed; retry in a moment") else onCatalog(found, next)
                }
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) onError("Catalog load failed: ${error.description}")
        }
    }
}

private val CATALOG_SCRIPT = """(function(){
  const out=[]; const seen=new Set();
  for(const a of document.querySelectorAll('a[href*="/mi-band-5/view/"]')){
    const u=new URL(a.href); const m=u.pathname.match(/\/view\/(\d+)/); if(!m||seen.has(m[1])) continue; seen.add(m[1]);
    let card=a;
    for(let i=0;i<6&&card.parentElement;i++){
      const parent=card.parentElement;
      if(parent.querySelectorAll('a[href*="/mi-band-5/view/"]').length>1) break;
      card=parent;
    }
    const img=card.querySelector('img');
    const title=(a.getAttribute('title')||img?.getAttribute('title')||img?.alt||'').trim();
    const lines=(card.innerText||'').split('\n').map(x=>x.trim()).filter(Boolean);
    const subtitle=lines.filter(x=>x!==title&&x!=='Mi Band 5').slice(0,2).join(' • ');
    const image=img?.getAttribute('data-original')||img?.getAttribute('data-lazy-src')||img?.getAttribute('data-src')||img?.currentSrc||img?.src||'';
    out.push({id:m[1],title:title&&title!=='Mi Band 5'?title:'Watchface #'+m[1],subtitle,url:u.href,image});
  }
  const nextLink=[...document.querySelectorAll('a[href]')].find(a=>/next/i.test((a.innerText||a.textContent||'').trim()));
  const next=nextLink?new URL(nextLink.href).href:'';
  return JSON.stringify({faces:out,next:next});
})()"""

private val VARIANTS_SCRIPT = """(function(){
  const out=[]; const seen=new Set();
  for(const a of document.querySelectorAll('a[href*="/dl/mi-band-5/bin/"]')){
    const href=new URL(a.href).href; if(seen.has(href)) continue; seen.add(href);
    out.push({name:(a.innerText||a.getAttribute('title')||href.split('/').pop()).trim(),url:href});
  }
  return JSON.stringify(out);
})()"""

private fun <T> parseJsonArray(raw: String, convert: (org.json.JSONObject) -> T): List<T> = runCatching {
    val decoded = JSONTokener(raw).nextValue() as? String ?: return emptyList()
    val array = JSONArray(decoded)
    (0 until array.length()).mapNotNull { index -> array.optJSONObject(index)?.let(convert) }
}.getOrDefault(emptyList())

private fun parseCatalogPage(raw: String): Pair<List<CatalogFace>, String?> = runCatching {
    val decoded = JSONTokener(raw).nextValue() as? String ?: return emptyList<CatalogFace>() to null
    val root = JSONObject(decoded)
    val array = root.optJSONArray("faces") ?: JSONArray()
    val faces = (0 until array.length()).mapNotNull { index ->
        array.optJSONObject(index)?.let { item ->
            CatalogFace(
                id = item.optString("id"),
                title = item.optString("title"),
                subtitle = item.optString("subtitle"),
                pageUrl = item.optString("url"),
                previewUrl = item.optString("image")
            )
        }
    }.distinctBy { it.id }.filter { it.id.isNotBlank() }
    val nextUri = Uri.parse(root.optString("next")).normalizeScheme()
    val next = nextUri.toString().takeIf {
        nextUri.scheme == "https" && nextUri.host == "amazfitwatchfaces.com" && nextUri.path?.startsWith("/mi-band-5/") == true
    }
    faces to next
}.getOrDefault(emptyList<CatalogFace>() to null)

private fun downloadFace(
    webView: WebView?,
    vm: BandViewModel,
    variant: FaceVariant,
    onProgress: (String) -> Unit,
    onReady: (String, ByteArray) -> Unit
) {
    val uri = Uri.parse(variant.url)
    if (webView == null || uri.scheme != "https" || uri.host != "amazfitwatchfaces.com") {
        onProgress("Blocked an invalid download link")
        return
    }
    val name = uri.lastPathSegment ?: "mi-band-5-watchface.bin"
    vm.log("Fetching watchface in catalog WebView session: $name")
    val bridgeName = "Band5Download"
    val bridge = object {
        @JavascriptInterface
        fun complete(ok: Boolean, payload: String) {
            webView.post {
                webView.removeJavascriptInterface(bridgeName)
                if (!ok) {
                    onProgress("Download failed: $payload")
                    vm.log("Watchface WebView download failed: $payload")
                    return@post
                }
                runCatching { Base64.decode(payload, Base64.DEFAULT) }
                    .onSuccess { bytes ->
                        if (isMiBand5Watchface(bytes)) onReady(name, bytes)
                        else {
                            onProgress("The catalog response is not a valid Mi Band 5 watchface")
                            vm.log("Rejected catalog response: not a Mi Band 5 binary")
                        }
                    }
                    .onFailure { error -> onProgress("Could not decode the downloaded face: ${error.message ?: "invalid data"}") }
            }
        }
    }
    webView.addJavascriptInterface(bridge, bridgeName)
    val script = """(async()=>{try{
      const r=await fetch(${JSONObject.quote(variant.url)},{credentials:'include',headers:{'Accept':'application/octet-stream,*/*'}});
      if(!r.ok) { window.$bridgeName.complete(false,'HTTP '+r.status); return; }
      const b=await r.arrayBuffer(); if(b.byteLength>20971520) { window.$bridgeName.complete(false,'File is too large'); return; }
      const a=new Uint8Array(b); let s=''; for(let i=0;i<a.length;i+=0x8000) s+=String.fromCharCode(...a.subarray(i,i+0x8000));
      window.$bridgeName.complete(true,btoa(s));
    }catch(e){window.$bridgeName.complete(false,String(e))}})()"""
    webView.evaluateJavascript(script, null)
}

private fun isMiBand5Watchface(bytes: ByteArray): Boolean {
    if (bytes.size < 256 || bytes.size > 20 * 1024 * 1024) return false
    return bytes[0] == 'U'.code.toByte() && bytes[1] == 'I'.code.toByte() &&
        bytes[2] == 'H'.code.toByte() && bytes[3] == 'H'.code.toByte()
}
