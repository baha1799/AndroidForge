package com.baha.miband5.ui

import android.app.DownloadManager
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.webkit.URLUtil
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.baha.miband5.BandViewModel

private const val BAND5_SHOP_URL = "https://amazfitwatchfaces.com/mi-band-5/fresh"

@Composable
fun WatchfaceShopScreen(vm: BandViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var pickedName by remember { mutableStateOf<String?>(null) }
    var pickedBytes by remember { mutableStateOf<ByteArray?>(null) }
    var downloadMessage by remember { mutableStateOf("Browse the Mi Band 5 catalog. Downloads load here automatically.") }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Could not open the selected file")
        }.onSuccess { bytes ->
            pickedBytes = bytes
            pickedName = uri.lastPathSegment?.substringAfterLast(':') ?: "watchface file"
            downloadMessage = "${bytes.size} bytes ready to install"
        }.onFailure {
            downloadMessage = "Could not read file: ${it.message ?: "unknown error"}"
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Mi Band 5 watchface shop", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Tap a design, then Download. The file will load here automatically.", style = MaterialTheme.typography.bodySmall)
        Text("Uses the Mi Band 5 transfer sequence captured from Zepp Life. A face with an existing ID may replace that saved face.", style = MaterialTheme.typography.bodySmall)
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                buildShopWebView(ctx, vm,
                    onDownloaded = { name, bytes ->
                        pickedName = name
                        pickedBytes = bytes
                        downloadMessage = "$name downloaded (${bytes.size} bytes). Ready to install."
                    },
                    onStatus = { downloadMessage = it }
                )
            }
        )
        Text(downloadMessage, style = MaterialTheme.typography.bodySmall)
        pickedName?.let { Text("Selected: $it", style = MaterialTheme.typography.bodySmall) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { filePicker.launch(arrayOf("application/octet-stream", "*/*")) },
                modifier = Modifier.weight(1f)
            ) { Text("Choose .bin") }
            Button(
                onClick = { pickedBytes?.let(vm::installWatchface) },
                enabled = pickedBytes != null && state.connected && state.installProgress == null,
                modifier = Modifier.weight(1f)
            ) { Text(if (state.connected) "Install to band" else "Connect to install") }
        }
        state.installProgress?.let { progress ->
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text("Uploading ${(progress * 100).toInt()}%")
        }
        state.installMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

private fun buildShopWebView(
    context: Context,
    vm: BandViewModel,
    onDownloaded: (String, ByteArray) -> Unit,
    onStatus: (String) -> Unit
): WebView = WebView(context).apply {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.setSupportMultipleWindows(false)
    webViewClient = WebViewClient()
    setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
        val uri = runCatching { Uri.parse(url) }.getOrNull()
        if (uri?.scheme != "https") {
            onStatus("Download blocked: the catalog must provide an HTTPS file")
            return@setDownloadListener
        }
        val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .ifBlank { "mi-band-5-watchface.bin" }
        val request = DownloadManager.Request(uri)
            .setTitle(name)
            .setDescription("Mi Band 5 watchface")
            .setMimeType(mimeType)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, name)
        if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val id = runCatching { manager.enqueue(request) }.getOrElse {
            onStatus("Download could not start: ${it.message ?: "unknown error"}")
            return@setDownloadListener
        }
        vm.log("Downloading watchface: $name")
        onStatus("Downloading $name…")

        val handler = Handler(Looper.getMainLooper())
        lateinit var poll: Runnable
        poll = Runnable {
            var cursor: Cursor? = null
            try {
                cursor = manager.query(DownloadManager.Query().setFilterById(id))
                if (cursor == null || !cursor.moveToFirst()) {
                    handler.postDelayed(poll, 800)
                    return@Runnable
                }
                when (cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        val fileUri = manager.getUriForDownloadedFile(id)
                        val bytes = fileUri?.let { context.contentResolver.openInputStream(it)?.use { input -> input.readBytes() } }
                        if (bytes == null || bytes.isEmpty()) onStatus("Download finished, but the file is empty or unreadable")
                        else if (bytes.size > 20 * 1024 * 1024) onStatus("Downloaded file is too large to load")
                        else {
                            vm.log("Watchface download complete (${bytes.size} bytes)")
                            onDownloaded(name, bytes)
                        }
                    }
                    DownloadManager.STATUS_FAILED -> {
                        val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                        onStatus("Download failed (error $reason)")
                        vm.log("Watchface download failed ($reason)")
                    }
                    else -> handler.postDelayed(poll, 800)
                }
            } catch (error: Exception) {
                onStatus("Could not load downloaded file: ${error.message ?: "unknown error"}")
            } finally {
                cursor?.close()
            }
        }
        handler.postDelayed(poll, 500)
    }
    loadUrl(BAND5_SHOP_URL)
}
