package com.baha.miband5

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.CRC32
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

/**
 * Minimal Huami/Mi Band 5 GATT client: authenticates with the 16-byte secret key,
 * then offers battery, steps, heart rate, vibrate, text notification and time sync.
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BandGatt(private val ctx: Context, private val key: ByteArray, private val cb: Callbacks) {

    interface Callbacks {
        fun log(msg: String)
        fun onAuthenticated()
        fun onDisconnected()
        fun onBattery(level: Int, charging: Boolean)
        fun onSteps(steps: Int)
        fun onHeartRate(bpm: Int)
    }

    companion object {
        private fun huami(id: Int) =
            UUID.fromString(String.format(Locale.ROOT, "0000%04x-0000-3512-2118-0009af100700", id))
        private fun std(id: Int) =
            UUID.fromString(String.format(Locale.ROOT, "0000%04x-0000-1000-8000-00805f9b34fb", id))

        val AUTH = huami(0x0009)
        val BATTERY = huami(0x0006)
        val STEPS = huami(0x0007)
        val HR_CTRL = std(0x2A39)
        val HR_MEAS = std(0x2A37)
        val ALERT_LEVEL = std(0x2A06)
        val NEW_ALERT = std(0x2A46)
        val CUR_TIME = std(0x2A2B)
        val FW_REVISION = std(0x2A26)
        val CCCD = std(0x2902)

        // Mi Band 5 install service, confirmed from a Zepp Life HCI capture.
        val FW_CONTROL = huami(0x1531)
        val FW_DATA = huami(0x1532)

        const val FILE_TYPE_FIRMWARE = 0
        const val FILE_TYPE_RESOURCE = 1
        const val FILE_TYPE_WATCHFACE = 8
    }

    interface InstallCallbacks {
        fun onLog(msg: String)
        fun onProgress(sentBytes: Int, totalBytes: Int)
        fun onResult(success: Boolean, message: String)
    }

    /**
     * Upload a watchface over Huami's REAL "DfuV5" protocol, decompiled straight from
     * Zepp Life's own source (NewDfuProfile.kt + DfuV5ProcessorImpl.kt in the base APK) -
     * not a guess, and not the invented 0x01/0xA0/0x03/0x04/0x20 scheme this file used to
     * have. Commands (all on FW_CONTROL aka "cpt"):
     *   0xD1 query status   -> must be IDLE/WAITING_NEXT_FIRMWARE
     *   0xD0 query protocol -> response gives maxChunkSize (band-chosen, not hardcoded)
     *   0xD2 PREPARE  [0xD2, fileType, size(LE32), crc32(LE32), maxChunkSize(LE16), mode]
     *   0xD3 START    [0xD3, freshFlag]  (1 = fresh, 0 = resume)
     *   -> stream bytes to FW_DATA ("pkt") in MTU-sized writes; after each maxChunkSize
     *      batch, wait for a 0xD4 ack (confirms bytes received so far, or asks retry)
     *   0xD5 VALIDATE (checksum trigger, fire-and-forget) -> async 0xD5 ack
     *   0xD6 APPLY/upgrade-now (fire-and-forget) -> async 0xD6 ack
     * Success is code==1 for every single step (confirmed directly from the decompiled
     * Kotlin data classes - PrepareResponse/StartTransferResponse/ValidateResponse/
     * UpgradeResponse all define success as code==1, no exceptions).
     */
    fun installFile(data: ByteArray, fileType: Int, cb: InstallCallbacks) {
        if (!authenticated) { cb.onResult(false, "Not authenticated"); return }
        if (fileType != FILE_TYPE_WATCHFACE) {
            cb.onResult(false, "Only Mi Band 5 watchface transfers are implemented")
            return
        }
        val ctrl = ch(FW_CONTROL)
        val dataChar = ch(FW_DATA)
        if (ctrl == null || dataChar == null) {
            cb.onResult(false, "Firmware service not found on this device"); return
        }
        if (data.isEmpty() || data.size > 0xFFFFFFFL) {
            cb.onResult(false, "Invalid watchface file size: ${data.size}")
            return
        }

        val crc32 = CRC32().apply { update(data) }.value
        var sentTotal = 0
        var maxChunkSize = 4096 // overwritten by the band's own answer to the 0xD0 query
        var stage = 0 // 0=await status(D1), 1=await protocolInfo(D0), 2=await prepare(D2),
                       // 3=await start(D3), 4=mid-transfer(D4 acks), 5=await validate(D5),
                       // 6=await apply(D6)
        cb.onLog("Watchface file: ${data.size} bytes, CRC32=0x${crc32.toString(16).padStart(8, '0')}")

        fun le16(v: Int) = byteArrayOf((v and 0xff).toByte(), ((v shr 8) and 0xff).toByte())
        fun le32(v: Long) = byteArrayOf(
            (v and 0xff).toByte(), ((v shr 8) and 0xff).toByte(),
            ((v shr 16) and 0xff).toByte(), ((v shr 24) and 0xff).toByte()
        )
        fun readU16(b: ByteArray, off: Int) = (b[off].toInt() and 0xff) or ((b[off + 1].toInt() and 0xff) shl 8)
        fun readU32(b: ByteArray, off: Int) = ((b[off].toLong() and 0xff) or ((b[off + 1].toLong() and 0xff) shl 8) or
            ((b[off + 2].toLong() and 0xff) shl 16) or ((b[off + 3].toLong() and 0xff) shl 24))

        fun sendPrepare() {
            stage = 2
            val init = byteArrayOf(0xD2.toByte(), fileType.toByte()) + le32(data.size.toLong()) +
                le32(crc32) + le16(maxChunkSize) + byteArrayOf(0) // mode=FOREGROUND
            cb.onLog("Sending PREPARE (0xD2): ${hex(init)}")
            write(FW_CONTROL, init)
        }

        fun sendNextSuperChunk() {
            if (sentTotal >= data.size) {
                stage = 5
                cb.onLog("All bytes sent; sending VALIDATE (0xD5)")
                write(FW_CONTROL, byteArrayOf(0xD5.toByte()))
                return
            }
            val end = minOf(sentTotal + maxChunkSize, data.size)
            var off = sentTotal
            val mtuChunk = (negotiatedMtu - 3).coerceAtLeast(20)
            while (off < end) {
                val pieceEnd = minOf(off + mtuChunk, end)
                val piece = data.copyOfRange(off, pieceEnd)
                enqueue {
                    dataChar.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    dataChar.value = piece
                    gatt?.writeCharacteristic(dataChar) ?: false
                }
                off = pieceEnd
            }
            cb.onProgress(end, data.size)
            stage = 4
            // Band acks with a 0xD4 notify once it has processed this super-chunk.
        }

        notifyHook = { uuid, value ->
            if (uuid == FW_CONTROL) {
                cb.onLog("FW_CONTROL notify: ${hex(value)}")
                if (value.size >= 3 && value[0] == 0x10.toByte()) {
                    val echoedCmd = value[1].toInt() and 0xff
                    val code = value[2].toInt() and 0xff
                    when (echoedCmd) {
                        0xD1 -> { // status query ack
                            if (code != 1) { cb.onResult(false, "Band rejected status query: ${hex(value)}"); notifyHook = null }
                            else {
                                stage = 1
                                cb.onLog("Status OK; querying protocol info (0xD0)")
                                write(FW_CONTROL, byteArrayOf(0xD0.toByte()))
                            }
                        }
                        0xD0 -> { // protocol info ack: [0x10,0xD0,code, version(1B), maxChunkSize(LE16)]
                            if (code != 1 || value.size < 6) {
                                cb.onResult(false, "Band rejected protocol query: ${hex(value)}"); notifyHook = null
                            } else {
                                maxChunkSize = readU16(value, 4)
                                cb.onLog("Protocol info OK; band maxChunkSize=$maxChunkSize")
                                sendPrepare()
                            }
                        }
                        0xD2 -> { // prepare ack
                            if (code != 1) { cb.onResult(false, "Band rejected PREPARE: ${hex(value)}"); notifyHook = null }
                            else {
                                stage = 3
                                cb.onLog("PREPARE acknowledged; sending START (0xD3)")
                                write(FW_CONTROL, byteArrayOf(0xD3.toByte(), 1)) // 1 = fresh start
                            }
                        }
                        0xD3 -> { // start-transfer ack
                            if (code != 1) { cb.onResult(false, "Band rejected START: ${hex(value)}"); notifyHook = null }
                            else {
                                cb.onLog("START acknowledged; beginning data transfer")
                                sendNextSuperChunk()
                            }
                        }
                        0xD4 -> { // transfer-continue ack: [0x10,0xD4,code, size(LE32), retry(1B), ...]
                            if (stage != 4) { /* stray/late ack, ignore */ }
                            else if (value.size >= 8) {
                                val confirmedSize = readU32(value, 3).toInt()
                                val retry = value[7].toInt() != 0
                                val justSent = minOf(sentTotal + maxChunkSize, data.size)
                                if (confirmedSize == justSent) {
                                    sentTotal = justSent
                                    sendNextSuperChunk()
                                } else if (retry) {
                                    cb.onLog("Band asked to retry last chunk (confirmed=$confirmedSize, expected=$justSent)")
                                    sendNextSuperChunk() // re-sends same [sentTotal, justSent) range
                                } else {
                                    cb.onResult(false, "Transfer mismatch: confirmed=$confirmedSize expected=$justSent")
                                    notifyHook = null
                                }
                            } else {
                                cb.onLog("Short 0xD4 ack (${value.size} bytes), ignoring")
                            }
                        }
                        0xD5 -> { // validate/checksum ack
                            if (code == 1) {
                                cb.onLog("Checksum validated; sending APPLY (0xD6)")
                                stage = 6
                                write(FW_CONTROL, byteArrayOf(0xD6.toByte()))
                            } else {
                                cb.onResult(false, "Checksum validation failed: ${hex(value)}")
                                notifyHook = null
                            }
                        }
                        0xD6 -> { // apply/upgrade-now ack
                            if (code == 1) {
                                cb.onResult(true, "Watchface installed successfully (${data.size} bytes)")
                            } else {
                                cb.onResult(false, "Band rejected APPLY: ${hex(value)}")
                            }
                            notifyHook = null
                        }
                        else -> cb.onLog("Unhandled command echo 0x${echoedCmd.toString(16)}")
                    }
                }
            }
        }

        enqueue {
            gatt?.setCharacteristicNotification(ctrl, true)
            val d = ctrl.getDescriptor(CCCD)
            d?.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            d?.let { gatt?.writeDescriptor(it) } ?: false
        }
        stage = 0
        cb.onLog("Querying upgrade status (0xD1)")
        write(FW_CONTROL, byteArrayOf(0xD1.toByte()))
    }

    // Lets installFile() intercept notifications without disturbing the main handleValue() path.
    private var notifyHook: ((UUID, ByteArray) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private val queue = java.util.LinkedList<() -> Boolean>()
    private var busy = false
    private var negotiatedMtu = 23
    var authenticated = false
        private set
    private var hrActive = false

    // ---------- connection ----------
    fun connect(device: BluetoothDevice) {
        cb.log("Connecting to ${device.address}…")
        gatt = device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        hrActive = false
        queue.clear(); busy = false; authenticated = false
        gatt?.disconnect()
    }

    // ---------- serialized GATT operations ----------
    private fun enqueue(op: () -> Boolean) {
        main.post { queue.add(op); pump() }
    }

    private fun pump() {
        if (busy) return
        val op = queue.poll() ?: return
        busy = true
        if (!op()) { busy = false; pump() }
    }

    private fun done() { main.post { busy = false; pump() } }

    private fun ch(uuid: UUID): BluetoothGattCharacteristic? =
        gatt?.services?.firstNotNullOfOrNull { it.getCharacteristic(uuid) }

    private fun write(uuid: UUID, data: ByteArray) = enqueue {
        val c = ch(uuid)
        if (c == null) { cb.log("Characteristic missing: $uuid"); false } else {
            c.writeType =
                if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0)
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            c.value = data
            gatt?.writeCharacteristic(c) ?: false
        }
    }

    private fun read(uuid: UUID) = enqueue {
        val c = ch(uuid)
        if (c == null) { cb.log("Characteristic missing: $uuid"); false }
        else gatt?.readCharacteristic(c) ?: false
    }

    private fun subscribe(uuid: UUID) = enqueue {
        val c = ch(uuid)
        val d = c?.getDescriptor(CCCD)
        if (c == null || d == null) { cb.log("Cannot subscribe: $uuid"); false } else {
            gatt?.setCharacteristicNotification(c, true)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt?.writeDescriptor(d) ?: false
        }
    }

    // ---------- GATT callbacks ----------
    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                cb.log("Connected, requesting BLE MTU for watchface transfer…")
                main.post {
                    val requested = try { g.requestMtu(247) } catch (_: SecurityException) { false }
                    if (!requested) {
                        cb.log("MTU request unavailable; using default MTU")
                        negotiatedMtu = 23
                        g.discoverServices()
                    }
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                main.post {
                    authenticated = false; hrActive = false
                    queue.clear(); busy = false
                    g.close()
                    cb.log("Disconnected (status $status)")
                    cb.onDisconnected()
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            main.post {
                negotiatedMtu = if (status == BluetoothGatt.GATT_SUCCESS) minOf(mtu, 247) else 23
                cb.log("BLE MTU: $negotiatedMtu${if (status == BluetoothGatt.GATT_SUCCESS) "" else " (negotiation failed)"}")
                g.discoverServices()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            main.post {
                cb.log("Services found, authenticating…")
                subscribe(AUTH)
                write(AUTH, byteArrayOf(0x82.toByte(), 0x00)) // request random number
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            val v = c.value ?: byteArrayOf()
            main.post { handleValue(c.uuid, v) }
            done()
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) cb.log("Write to ${c.uuid.toString().take(8)} failed ($status)")
            done()
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) = done()

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            main.post { handleValue(c.uuid, v) }
        }
    }

    // ---------- incoming data ----------
    private fun handleValue(uuid: UUID, v: ByteArray) {
        notifyHook?.let { it(uuid, v); if (uuid == FW_CONTROL) return }
        when (uuid) {
            AUTH -> handleAuth(v)
            BATTERY -> if (v.size >= 3) cb.onBattery(v[1].toInt() and 0xff, v[2].toInt() == 1)
            STEPS -> if (v.size >= 3) cb.onSteps((v[1].toInt() and 0xff) or ((v[2].toInt() and 0xff) shl 8))
            HR_MEAS -> if (v.size >= 2 && (v[1].toInt() and 0xff) > 0) cb.onHeartRate(v[1].toInt() and 0xff)
            FW_REVISION -> cb.log("Band firmware revision: ${v.toString(Charsets.UTF_8).trimEnd('\u0000').ifBlank { hex(v) }}")
            else -> cb.log("Data ${uuid.toString().take(8)}: ${hex(v)}")
        }
    }

    private fun handleAuth(v: ByteArray) {
        if (v.size < 3 || v[0] != 0x10.toByte()) { cb.log("Auth message: ${hex(v)}"); return }
        val cmd = v[1].toInt() and 0xff
        val ok = v[2] == 0x01.toByte()
        when {
            cmd == 0x82 && ok && v.size >= 19 -> {
                val random = v.copyOfRange(3, 19)
                val cipher = Cipher.getInstance("AES/ECB/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))
                write(AUTH, byteArrayOf(0x83.toByte(), 0x00) + cipher.doFinal(random))
            }
            cmd == 0x83 && ok -> {
                authenticated = true
                cb.log("Authenticated ✔")
                cb.onAuthenticated()
                read(FW_REVISION)
                subscribe(HR_MEAS)
                readBattery(); readSteps()
            }
            else -> cb.log("Auth failed: ${hex(v)} (wrong key, or band still bound to another app?)")
        }
    }

    // ---------- features ----------
    private fun need(): Boolean { if (!authenticated) cb.log("Not authenticated yet"); return authenticated }

    fun readBattery() { if (need()) read(BATTERY) }
    fun readSteps() { if (need()) read(STEPS) }

    fun vibrate() { if (need()) write(ALERT_LEVEL, byteArrayOf(0x03)) }

    fun startHeartRate() {
        if (!need()) return
        hrActive = true
        write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x00))
        write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x01))
        pingHr()
    }

    fun stopHeartRate() {
        hrActive = false
        if (authenticated) write(HR_CTRL, byteArrayOf(0x15, 0x02, 0x00))
    }

    private fun pingHr() {
        main.postDelayed({
            if (hrActive && authenticated) { write(HR_CTRL, byteArrayOf(0x16)); pingHr() }
        }, 12_000)
    }

    /** Experimental: category 0x05 (SMS/MMS) + 1 alert + UTF-8 text. */
    fun notifyText(text: String) {
        if (need()) write(NEW_ALERT, byteArrayOf(0x05, 0x01) + text.toByteArray(Charsets.UTF_8))
    }

    /** Experimental: Current Time characteristic (10 bytes) + timezone in 15-min units. */
    fun syncTime() {
        if (!need()) return
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val dow = ((cal.get(Calendar.DAY_OF_WEEK) + 5) % 7) + 1 // Mon=1 … Sun=7
        val tz = (TimeZone.getDefault().getOffset(cal.timeInMillis) / 900_000).toByte()
        write(
            CUR_TIME, byteArrayOf(
                (year and 0xff).toByte(), (year shr 8).toByte(),
                (cal.get(Calendar.MONTH) + 1).toByte(), cal.get(Calendar.DAY_OF_MONTH).toByte(),
                cal.get(Calendar.HOUR_OF_DAY).toByte(), cal.get(Calendar.MINUTE).toByte(),
                cal.get(Calendar.SECOND).toByte(), dow.toByte(), 0, 0, tz
            )
        )
    }
}
