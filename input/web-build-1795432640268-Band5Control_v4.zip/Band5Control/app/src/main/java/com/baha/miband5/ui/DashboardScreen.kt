package com.baha.miband5.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.baha.miband5.BandUiState
import com.baha.miband5.BandViewModel

@Composable
fun DashboardScreen(
    vm: BandViewModel,
    onScanRequested: (String) -> Unit,
    onReconnectRequested: () -> Unit
) {
    val state by vm.state.collectAsState()
    var keyField by rememberSaveable { mutableStateOf(vm.savedKeyHex()) }
    val keyCharCount = keyField
        .replace("0x", "", ignoreCase = true)
        .count { it in "0123456789abcdefABCDEF" }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatusCard(state)

        OutlinedTextField(
            value = keyField,
            onValueChange = { keyField = it },
            label = { Text("Auth key (32 hex chars)") },
            supportingText = { Text("$keyCharCount / 32 hex characters") },
            isError = keyField.isNotEmpty() && keyCharCount != 32,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    if (vm.parseKey(keyField) != null) onScanRequested(keyField)
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Bluetooth, null); Spacer(Modifier.width(6.dp)); Text("Scan & connect")
            }
            OutlinedButton(
                onClick = {
                    if (vm.parseKey(keyField) != null) onReconnectRequested()
                },
                modifier = Modifier.weight(1f)
            ) { Text("Reconnect") }
        }
        OutlinedButton(onClick = { vm.disconnect() }, modifier = Modifier.fillMaxWidth()) { Text("Disconnect") }

        Divider()

        InfoRow(icon = Icons.Default.BatteryFull, label = "Battery",
            value = state.battery?.let { "$it%" + if (state.charging) " (charging)" else "" } ?: "–")
        InfoRow(icon = Icons.Default.DirectionsWalk, label = "Steps",
            value = state.steps?.toString() ?: "–")
        InfoRow(icon = Icons.Default.Favorite, label = "Heart rate",
            value = state.heartRate?.let { "$it bpm" } ?: "–")

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.refresh() }, modifier = Modifier.weight(1f)) { Text("Refresh") }
            OutlinedButton(onClick = { vm.startHeartRate() }, modifier = Modifier.weight(1f)) { Text("Start HR") }
            OutlinedButton(onClick = { vm.stopHeartRate() }, modifier = Modifier.weight(1f)) { Text("Stop HR") }
        }

        Text("Automatic heart rate", fontWeight = FontWeight.Bold)
        Text(
            "The band takes a reading on its own at this interval - no need to press " +
            "Start each time. Still needs to be worn to get a reading.",
            style = MaterialTheme.typography.bodySmall
        )
        HrIntervalPicker(
            selectedMinutes = state.heartRateIntervalMinutes,
            onSelect = { vm.setHeartRateInterval(it) }
        )

        Divider()

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.vibrate() }, modifier = Modifier.weight(1f)) { Text("Vibrate") }
            OutlinedButton(onClick = { vm.sendTestNotification() }, modifier = Modifier.weight(1f)) { Text("Test notify") }
            OutlinedButton(onClick = { vm.syncTime() }, modifier = Modifier.weight(1f)) { Text("Sync time") }
        }

        Divider()
        Text("Log", fontWeight = FontWeight.Bold)
        LogView(state.log)
    }
}

@Composable
private fun StatusCard(state: BandUiState) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (state.connected) Icons.Default.BluetoothConnected else Icons.Default.BluetoothDisabled,
                contentDescription = null,
                tint = if (state.connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Mi Smart Band 5", style = MaterialTheme.typography.titleMedium)
                Text(state.statusText, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Text(label, Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.Bold)
    }
}

private val HR_INTERVAL_OPTIONS = listOf(
    0 to "Off", 1 to "1 min", 5 to "5 min", 10 to "10 min", 30 to "30 min", 60 to "1 hr"
)

@Composable
private fun HrIntervalPicker(selectedMinutes: Int, onSelect: (Int) -> Unit) {
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(HR_INTERVAL_OPTIONS) { (minutes, label) ->
            FilterChip(
                selected = selectedMinutes == minutes,
                onClick = { onSelect(minutes) },
                label = { Text(label) }
            )
        }
    }
}

@Composable
fun LogView(lines: List<String>) {
    LazyColumn(Modifier.heightIn(max = 220.dp)) {
        items(lines.takeLast(50)) { line ->
            Text(line, style = MaterialTheme.typography.bodySmall)
        }
    }
}
